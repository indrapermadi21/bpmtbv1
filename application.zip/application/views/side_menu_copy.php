<ul class="sidebar-menu">
                        <li class="active">
                            <a href="index.html">
                                <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                            </a>
                        </li>
                        <li class="treeview">
                            <a href="#">
                                <i class="fa fa-laptop"></i>
                                <span>Administrasi</span>
                                <!--i class="fa fa-angle-left pull-right"></i-->
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="#"><i class="fa fa-angle-double-right"></i>User</a></li>
                            </ul>
                        </li>
                        <li class="treeview">
                            <a href="#">
                                <i class="fa fa-laptop"></i>
                                <span>Master</span>
                                <!--i class="fa fa-angle-left pull-right"></i-->
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="#"><i class="fa fa-angle-double-right"></i>Data Pegawai</a></li>
                                <li><a href="#"><i class="fa fa-angle-double-right"></i>Retribusi</a></li>
                                <li><a href="#"><i class="fa fa-angle-double-right"></i>Tanda Tangan Laporan</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#" id="ppu" class="link-menu">
                                <i class="fa fa-laptop"></i>
                                <span>Perizinan Usaha</span>
                                <!--i class="fa fa-angle-left pull-right"></i-->
                            </a>
                        </li>
                        <li >
                            <a href="#" id="ppnu" class="link-menu">
                                <i class="fa fa-laptop"></i>
                                <span>Perizinan Non Usaha</span>
                                <!--i class="fa fa-angle-left pull-right"></i-->
                            </a>
                            <!--ul class="treeview-menu">
                                <li><a href="#"><i class="fa fa-angle-double-right"></i>Departemen</a></li>
                                <li><a href="#"><i class="fa fa-angle-double-right"></i>Pegawai</a></li>
                                <li><a href="#"><i class="fa fa-angle-double-right"></i>Jabatan</a></li>
                            </ul-->
                        </li>
                        <li >
                            <a href="#" id="pppm" class="link-menu">
                                <i class="fa fa-laptop"></i>
                                <span>Perizinan Penanaman Modal</span>
                                <!--i class="fa fa-angle-left pull-right"></i-->
                            </a>
                            <!--ul class="treeview-menu">
                                <li><a href="pages/UI/general.html"><i class="fa fa-angle-double-right"></i>Departemen</a></li>
                                <li><a href="pages/UI/icons.html"><i class="fa fa-angle-double-right"></i>Pegawai</a></li>
                                <li><a href="pages/UI/icons.html"><i class="fa fa-angle-double-right"></i>Jabatan</a></li>
                            </ul-->
                        </li>
                    </ul>
                </section>
                <!-- /.sidebar -->
            </aside>