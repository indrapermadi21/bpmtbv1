<script type="text/javascript">

    $(document).ready(function () {
        
    });
</script>

<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <strong><center><h2>Pelayanan Perizinan Non Usaha</h2></center></strong>
                </div><!-- /.box-header -->
                <div class="box-body ">
                    <table boder="0" width="100%">
                        <tr>
                            <td>
                                <div class="list-group">
                                    <a href="#" class="list-group-item"><i class="fa fa-paper-plane"></i>&nbsp;&nbsp;Izin Lokasi</a>
                                    <a href="<?php echo base_url()?>c_ppnu/ippt" class="list-group-item"><i class="fa fa-paper-plane"></i>&nbsp;&nbsp;Izin Peruntukan Penggunaan Tanah ( IPPT )</a>
                                    <a href="#" class="list-group-item"><i class="fa fa-paper-plane"></i>&nbsp;&nbsp;Izin Pemanfaatan Ruang Milik Jalan ( RUMIJA )</a>
                                    <a href="#" class="list-group-item"><i class="fa fa-paper-plane"></i>&nbsp;&nbsp;Izin Dispensasi Jalan</a>
                                    <a href="#" class="list-group-item"><i class="fa fa-paper-plane"></i>&nbsp;&nbsp;Sertifikasi Laik Sehat</a>
                                    <a href="#" class="list-group-item"><i class="fa fa-paper-plane"></i>&nbsp;&nbsp;Izin Salon Kecantikan</a>
                                    <a href="#" class="list-group-item"><i class="fa fa-paper-plane"></i>&nbsp;&nbsp;Izin Penyelenggaraan Pendidikan dan Pelatihan</a>
                                    <a href="#" class="list-group-item"><i class="fa fa-paper-plane"></i>&nbsp;&nbsp;Izin Penyelenggaraan Kursus</a>
                                    <!--a href="#" class="list-group-item">&nbsp;&nbsp;</a>
                                    <a href="#" class="list-group-item">&nbsp;&nbsp;</a-->
                                </div>
                            </td>
                            <td width="50%">
                                <!--div class="list-group">
                                    <a href="#" class="list-group-item">&nbsp;&nbsp;</a>
                                    <a href="#" class="list-group-item">&nbsp;&nbsp;</a>
                                    <a href="#" class="list-group-item">&nbsp;&nbsp;</a>
                                    <a href="#" class="list-group-item">&nbsp;&nbsp;</a>
                                    <a href="#" class="list-group-item">&nbsp;&nbsp;</a>
                                    <a href="#" class="list-group-item">&nbsp;&nbsp;</a>
                                    <a href="#" class="list-group-item">&nbsp;&nbsp;</a>
                                    <a href="#" class="list-group-item">&nbsp;&nbsp;</a>
                                    <a href="#" class="list-group-item">&nbsp;&nbsp;</a>
                                    <a href="#" class="list-group-item">&nbsp;&nbsp;</a>
                                </div-->
                            </td>
                        </tr>
                    </table>

                </div><!-- /.box-body -->

            </div><!-- /.box -->
        </div>                
    </div><!--/.row-->

</section><!-- /.content -->