<!-- Main content -->
<section class="content">
    <center><h2>Selamat datang di Admin panel </h2></center>
</section><!-- /.content -->
</aside><!-- /.right-side -->
</div><!-- ./wrapper -->

<!-- add new calendar event modal -->
