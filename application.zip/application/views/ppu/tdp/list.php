
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <strong><center><h2>Pelayanan Perizinan Usaha</h2></center></strong>
                </div><!-- /.box-header -->
                <div class="box-body ">
                    Tes
                </div><!-- /.box-body -->

            </div><!-- /.box -->
        </div>                
    </div><!--/.row-->
