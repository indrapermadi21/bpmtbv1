

<!-- Right side column. Contains the navbar and content of the page -->
<!--aside class="right-side"-->
<!-- Content Header (Page header) -->
<section class="content-header">

    <!--ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Examples</a></li>
        <li class="active">Blank page</li>
    </ol-->
</section>