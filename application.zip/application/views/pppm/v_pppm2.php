
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <strong><center><h2>Pelayanan Perizinan Penanaman Modal</h2></center></strong>
                </div><!-- /.box-header -->
                <div class="box-body ">
                    <table boder="0" width="100%">
                        <tr>
                            <td width="50%">
                                <div class="list-group">
                                    <a href="#" class="list-group-item"><i class="fa fa-paper-plane"></i>&nbsp;&nbsp;Izin Prinsip</a>
                                    <a href="#" class="list-group-item"><i class="fa fa-paper-plane"></i>&nbsp;&nbsp;Izin Prinsip Perluasan</a>
                                    <a href="#" class="list-group-item"><i class="fa fa-paper-plane"></i>&nbsp;&nbsp;Izin Prinsip Perubahan</a>
                                    <a href="#" class="list-group-item"><i class="fa fa-paper-plane"></i>&nbsp;&nbsp;Izin Prinsip Penggabungan Perusahaan</a>
                                    <a href="#" class="list-group-item"><i class="fa fa-paper-plane"></i>&nbsp;&nbsp;Izin Usaha</a>
                                    <a href="#" class="list-group-item"><i class="fa fa-paper-plane"></i>&nbsp;&nbsp;Izin Usaha Perluasan</a>
                                    <a href="#" class="list-group-item"><i class="fa fa-paper-plane"></i>&nbsp;&nbsp;Izin Usaha Perubahan</a>
                                    <a href="#" class="list-group-item"><i class="fa fa-paper-plane"></i>&nbsp;&nbsp;Izin Usaha Penggabungan Perusahaan ( Merger )</a>
                                    <a href="#" class="list-group-item"><i class="fa fa-paper-plane"></i>&nbsp;&nbsp;Perpanjangan Izin Memperkerjakan Tenaga Asing ( IMTA )</a>
                                    <!--a href="#" class="list-group-item">&nbsp;&nbsp;</a-->
                                    
                                </div>
                            </td>
                            <td width="50%">
                                <!--div class="list-group">
                                    <a href="#" class="list-group-item">&nbsp;&nbsp;</a>
                                    <a href="#" class="list-group-item">&nbsp;&nbsp;</a>
                                    <a href="#" class="list-group-item">&nbsp;&nbsp;</a>
                                    <a href="#" class="list-group-item">&nbsp;&nbsp;</a>
                                    <a href="#" class="list-group-item">&nbsp;&nbsp;</a>
                                    <a href="#" class="list-group-item">&nbsp;&nbsp;</a>
                                    <a href="#" class="list-group-item">&nbsp;&nbsp;</a>
                                    <a href="#" class="list-group-item">&nbsp;&nbsp;</a>
                                    <a href="#" class="list-group-item">&nbsp;&nbsp;</a>
                                    <a href="#" class="list-group-item">&nbsp;&nbsp;</a>
                                </div-->
                            </td>
                        </tr>
                    </table>

                </div><!-- /.box-body -->

            </div><!-- /.box -->
        </div>                
    </div><!--/.row-->
