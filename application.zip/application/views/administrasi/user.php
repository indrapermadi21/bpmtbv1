<script type="text/javascript">

    $(document).ready(function () {
        var panel_list = $('#panel_list');
        var panel_form = $('#panel_form');

        //init 
        panel_form.hide();
        $('#user_table').dataTable();

    });

    function back_grid() {
        $('#panel_form').hide();
        $('#panel_list').show();
    }

    function create_user() {
        $('#form_user').trigger('reset');
        $('#form_status').val('add');
        $('#panel_form').show();
        $('#panel_list').hide();
    }

    function save_user() {
        var form_status = $('#form_status').val();

        var username = $('#username').val();
        var fullname = $('#fullname').val();
        var password = $('#password').val();
        var retype_password = $('#retype_password').val();
        var email = $('#email').val();
        var id = $('#id_user').val();


        if (password != retype_password) {
            alert('Password tidak sama ');
            return false;
        }

        if (form_status == 'add') {
            $.post('<?php echo base_url() ?>administrasi/user/save', {
                username: username,
                fullname: fullname,
                password: password,
                email: email
            }, function (r) {
                if (r.success) {
                    window.location.href = '<?php echo base_url() ?>administrasi/user';
                }
            })
        } else {
            $.post('<?php echo base_url() ?>administrasi/user/edit', {
                username: username,
                fullname: fullname,
                password: password,
                email: email,
                id: id
            }, function (r) {
                if (r.success) {
                    window.location.href = '<?php echo base_url() ?>administrasi/user';
                }
            })
        }
    }

    function edit_user(el) {

        $.post('<?php echo base_url() ?>administrasi/user/get_user', {
            id: el
        }, function (r) {
            if (r) {
                $('#id_user').val(r.data.id);
                $('#username').val(r.data.username);
                $('#fullname').val(r.data.fullname);
                $('#email').val(r.data.email);
                $('#form_status').val('edit');
                $('#panel_list').hide();
                $('#panel_form').show();

            }
        }, 'json');
    }

    function remove_user(el) {
        $.post('<?php echo base_url() ?>administrasi/user/delete', {
            id: el
        }, function () {
            window.location.href = '<?php echo base_url() ?>administrasi/user';
        })
    }
</script>

<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <!--strong><center><h2>Menu</h2></center></strong-->
                </div><!-- /.box-header -->
                <div class="box-body table-responsive">


                    <div id="panel_list" class="panel panel-default">
                        <div class="panel-heading"><a href="#" id="create_user" onclick="create_user()"><i class="fa fa-user-plus fa-2x"></i></a></div>
                        <div class="panel-body">
                            <table id="user_table" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th style="width: 20px">No.</th>
                                        <th style="width: 100px;">Username</th>
                                        <th style="width: 500px;">Full Name</th>
                                        <th style="width: 300px;">Last Login</th>
                                        <th style="width: 400px;">Email</th>
                                        <th style="width: 400px;">Date Added</th>
                                        <th style="width: 100px;"></th>
                                        <th style="width: 100px;"></th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php
                                    $i = 1;
                                    foreach ($list_user as $r) {
                                        ?>

                                        <tr>
                                            <td><?php echo $i; ?></td>
                                            <td><?php echo $r->username; ?></td>
                                            <td><?php echo $r->fullname ?></td>
                                            <td><?php echo $r->lastlogin ?></td>
                                            <td><?php echo $r->email ?></td>
                                            <td><?php echo $r->date_added ?></td>
                                            <td>
                                                <button class="btn btn-info" type="button" id="edit_user" onclick="edit_user(<?php echo $r->id ?>)"><i class="fa fa-pencil"></i></button>
                                            </td>
                                            <td>
                                                <button class="btn btn-warning" type="button" id="remove_user" onclick="remove_user(<?php echo $r->id ?>)"><i class="fa fa-trash"></i></button>

                                            </td>
                                                <!--td align="center"><button class="btn btn-info btn-sm" onclick="location.href='<?php echo base_url() ?>employee/edit/<?php echo $div->id; ?>'">&nbsp;&nbsp;Edit&nbsp;&nbsp;&nbsp;</button></td>
                                                <td align="center"><a class="btn btn-danger btn-sm" onclick="return confirm('Are your sure you want delete this record')" href="<?php echo base_url() ?>employee/delete/<?php echo $div->id ?>">Delete</a></td-->
                                        </tr>

                                        <?php
                                        $i++;
                                    }//end foreach
                                    ?>

                                </tbody>
                            </table>
                        </div>
                    </div>



                    <div id="panel_form" class="panel panel-default">
                        <div class="panel-heading">
                            <button class="btn btn-primary" id="back_grid" onclick="back_grid()"><i class="fa fa-table"></i></button>
                            <button class="btn btn-primary" id="save_user" onclick="save_user()"><i class="fa fa-save"></i></button>
                        </div>
                        <div class="panel-body">
                            <form id="form_user">
                                <div class="row">
                                    <div class="col-xs-2">
                                        <label for="username">Username : </label>
                                    </div>
                                    <div class="col-xs-2">
                                        <input type="hidden" id="form_status" >
                                        <input type="hidden" id="id_user" >
                                        <input type="text" class="form-control input-sm" id="username"/>
                                    </div>
                                </div>
                                <br/>
                                <div class="row">
                                    <div class="col-xs-2">
                                        <label for="fullname">Fullname: </label>
                                    </div>
                                    <div class="col-xs-2">
                                        <input type="text" class="form-control input-sm" id="fullname"/>
                                    </div>
                                </div>
                                <br/>
                                <div class="row">
                                    <div class="col-xs-2">
                                        <label for="password">Password: </label>
                                    </div>
                                    <div class="col-xs-2">
                                        <input type="password" class="form-control input-sm" id="password"/>
                                    </div>
                                </div>
                                <br/>
                                <div class="row">
                                    <div class="col-xs-2">
                                        <label for="retype_password">Retype Password: </label>
                                    </div>
                                    <div class="col-xs-2">
                                        <input type="password" class="form-control input-sm" id="retype_password"/>
                                    </div>
                                </div>
                                <br/>
                                <div class="row">
                                    <div class="col-xs-2">
                                        <label for="email">Email : </label>
                                    </div>
                                    <div class="col-xs-2">
                                        <input type="text" class="form-control input-sm" id="email"/>
                                    </div>
                                </div>
                                <br/>
                            </form>
                        </div>
                    </div>



                </div><!-- /.box-body -->

            </div><!-- /.box -->
        </div>                
    </div><!--/.row-->

</section><!-- /.content -->