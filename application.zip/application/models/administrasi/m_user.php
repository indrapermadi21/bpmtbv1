<?php

class M_user extends CI_Model {

    function list_user() {
        $query = $this->db->get('auth_user');
        return $query->result();
    }

    function is_saved($data) {
        $this->db->trans_begin();

        $this->db->insert('auth_user', $data);

        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
        } else {
            $this->db->trans_commit();
            return true;
        }
    }

    function is_edited($data, $id) {
        $this->db->trans_begin();

        $this->db->where('id', $id);
        $this->db->update('auth_user', $data);

        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
        } else {
            $this->db->trans_commit();
            return true;
        }
    }
    
    function delete_user($id){
        $this->db->where('id',$id);
        $this->db->delete('auth_user');
        return true;
    }

    function get_user($id) {
        $query = $this->db->query('select * from auth_user where id=' . $id);
        return $query->result();
    }

}

?>