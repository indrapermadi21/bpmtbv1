<?php

class M_tdp extends CI_Model{
    
    function list_tdp(){
        $query = $this->db->query('select * from ppu_tdp');
        return $query->result();
    }
    
    function is_saved($data){
        $this->db->trans_begin();

        $this->db->insert('ppu_tdp',$data);

        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
        } else {
            $this->db->trans_commit();
            return true;
        }
    }
    
    function getTdp($id_tdp){
        $query =$this->db->query('select * from ppu_tdp where id_tdp='.$id_tdp);
        return $query->result();
    }
    
    function getDataTdp($id_tdp){
        $query =$this->db->query('select * from ppu_tdp where id_tdp='.$id_tdp);
        return $query->row();
    }
    
}