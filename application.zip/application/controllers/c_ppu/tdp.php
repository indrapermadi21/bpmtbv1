<?php

class Tdp extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('ppu/m_tdp');
    }

    function index() {
        if ($this->session->userdata('is_log') != "") {
            $d['jenis_perizinan'] = 'Tanda Daftar Perusahaan';

            $d['type_perusahaan'] = $this->m_global->getTypePerusahaan("");
            $d['jenis_perusahaan'] = $this->m_global->getJenisPerusahaan("");
            $d['getStatus'] = $this->m_global->getStatusPerusahaan("");
            $d['list_tdp'] = $this->m_tdp->list_tdp();
            $d['content'] = 'ppu/tdp/lf_tdp';
            $this->load->view('template', $d);
        } else {
            header('location:' . base_url() . '');
        }
    }

    function getTdp() {
        $id_tdp = $this->input->post('id_tdp');
        $results = $this->m_tdp->getTdp($id_tdp);
        foreach ($results as $r) {
            $row['data'] = array(
                'id_tdp' => $r->id_tdp,
                'jenis_perizinan' => $r->jenis_perizinan,
                'tgl_pembuatan' => tgl_convert($r->tgl_pembuatan),
                'no_pelayanan' => $r->no_pelayanan,
                'keterangan' => $r->keterangan,
                'type_perusahaan' => $r->type_perusahaan,
                'jenis_perusahaan' => $r->jenis_perusahaan,
                'perusahaan_ke' => $r->perusahaan_ke,
                'nama_perusahaan' => $r->nama_perusahaan,
                'status_perusahaan' => $r->status_perusahaan,
                'npwp' => $r->npwp,
                'alamat' => $r->alamat,
                'kota' => $r->kota,
                'kecamatan' => $r->kecamatan,
                'kelurahan' => $r->kelurahan,
                'no_telp' => $r->no_telp,
                'penanggung_jawab' => $r->penanggung_jawab,
                'keg_up' => $r->keg_up,
                'kbli' => $r->kbli,
                'tgl_penetapan' => tgl_convert($r->tgl_penetapan),
                'tgl_berlaku' => tgl_convert($r->tgl_berlaku),
                'no_registrasi' => $r->no_registrasi,
                'nama_pejabat' => $r->nama_pejabat,
                'jabatan' => $r->jabatan,
                'nip' => $r->nip,
                'jumlah_retribusi' => $r->jumlah_retribusi
            );
        }
        echo json_encode($row);
    }

    function save() {
        $data = array(
            'jenis_perizinan' => $this->input->post('jenis_perizinan'),
            'tgl_pembuatan' => convert_tgl($this->input->post('tgl_pembuatan')),
            'no_pelayanan' => $this->input->post('no_pelayanan'),
            'keterangan' => $this->input->post('keterangan'),
            'type_perusahaan' => $this->input->post('type_perusahaan'),
            'jenis_perusahaan' => $this->input->post('jenis_perusahaan'),
            'perusahaan_ke' => $this->input->post('perusahaan_ke'),
            'nama_perusahaan' => $this->input->post('nama_perusahaan'),
            'status_perusahaan' => $this->input->post('status_perusahaan'),
            'npwp' => $this->input->post('npwp'),
            'alamat' => $this->input->post('alamat'),
            'kota' => $this->input->post('kota'),
            'kecamatan' => $this->input->post('kecamatan'),
            'kelurahan' => $this->input->post('kelurahan'),
            'no_telp' => $this->input->post('no_telp'),
            'penanggung_jawab' => $this->input->post('penanggung_jawab'),
            'keg_up' => $this->input->post('keg_up'),
            'kbli' => $this->input->post('kbli'),
            'tgl_penetapan' => convert_tgl($this->input->post('tgl_penetapan')),
            'tgl_berlaku' => convert_tgl($this->input->post('tgl_berlaku')),
            'no_registrasi' => $this->input->post('no_registrasi'),
            'nama_pejabat' => $this->input->post('nama_pejabat'),
            'jabatan' => $this->input->post('jabatan'),
            'nip' => $this->input->post('nip'),
            'jumlah_retribusi' => str_replace(",", "", $this->input->post('jumlah_retribusi'))
        );
        if ($result = $this->m_tdp->is_saved($data)) {
            echo json_encode(array_merge(array('success' => true)));
        }
    }

    function edit() {
        $data = array(
            'jenis_perizinan' => $this->input->post('jenis_perizinan'),
            'tgl_pembuatan' => convert_tgl($this->input->post('tgl_pembuatan')),
            'no_pelayanan' => $this->input->post('no_pelayanan'),
            'keterangan' => $this->input->post('keterangan'),
            'type_perusahaan' => $this->input->post('type_perusahaan'),
            'jenis_perusahaan' => $this->input->post('jenis_perusahaan'),
            'perusahaan_ke' => $this->input->post('perusahaan_ke'),
            'nama_perusahaan' => $this->input->post('nama_perusahaan'),
            'status_perusahaan' => $this->input->post('status_perusahaan'),
            'npwp' => $this->input->post('npwp'),
            'alamat' => $this->input->post('alamat'),
            'kota' => $this->input->post('kota'),
            'kecamatan' => $this->input->post('kecamatan'),
            'kelurahan' => $this->input->post('kelurahan'),
            'no_telp' => $this->input->post('no_telp'),
            'penanggung_jawab' => $this->input->post('penanggung_jawab'),
            'keg_up' => $this->input->post('keg_up'),
            'kbli' => $this->input->post('kbli'),
            'tgl_penetapan' => convert_tgl($this->input->post('tgl_penetapan')),
            'tgl_berlaku' => convert_tgl($this->input->post('tgl_berlaku')),
            'no_registrasi' => $this->input->post('no_registrasi'),
            'nama_pejabat' => $this->input->post('nama_pejabat'),
            'jabatan' => $this->input->post('jabatan'),
            'nip' => $this->input->post('nip'),
            'jumlah_retribusi' => str_replace(",", "", $this->input->post('jumlah_retribusi'))
        );
        if ($result = $this->m_tdp->is_edited($data)) {
            echo json_encode(array_merge(array('success' => true)));
        }
    }

    function export_doc() {
        $id_tdp = $this->uri->segment(4);
        $type = $this->uri->segment(5);
        $d['results'] = $this->m_tdp->getDataTdp($id_tdp);

        if ($d['results']->perusahaan_ke == '0') {
            $d['pendaftaran'] = 'BARU';
            $d['pembaruan'] = '0';
        } else {
            $d['pendaftaran'] = '-';
            $d['pembaruan'] = $d['results']->perusahaan_ke;
        }
        
        $d['status'] = $this->m_global->getStatusPerusahaan($d['results']->status_perusahaan);
        $d['type'] = $this->m_global->getTypePerusahaan($d['results']->type_perusahaan);
        //$status_perusahaan = $this->m_global->getJenis();

        if ($type == "doc") {
            header("Content-Type: application/vnd.ms-word");
            header("Expires: 0");
            header("Cache-Control:  must-revalidate, post-check=0, pre-check=0");
            header("Content-disposition: attachment; filename=export.doc");
        }

        $this->load->view('ppu/tdp/report_tdp', $d);
    }

}
