<?php

class User extends CI_Controller {

    function __Construct() {
        parent::__Construct();
        $this->load->model('administrasi/m_user');
    }

    function index() {
        if ($this->session->userdata('is_log') != "") {
            $d['list_user'] = $this->m_user->list_user();

            $d['content'] = 'administrasi/user';
            $this->load->view('template', $d);
        } else {
            header('location:' . base_url() . '');
        }
    }

    function save() {
        $data = array(
            'username' => $this->input->post('username'),
            'password' => md5($this->input->post('password')),
            'email' => $this->input->post('email'),
            'fullname' => $this->input->post('fullname'),
            'date_added' => date('Y-m-d'),
            'added_by' => $this->session->userdata('username')
        );

        if ($result = $this->m_user->is_saved($data)) {
            echo json_encode(array_merge(array('success' => true)));
        }
    }

    function edit() {
        $data = array(
            'username' => $this->input->post('username'),
            'password' => md5($this->input->post('password')),
            'email' => $this->input->post('email'),
            'fullname' => $this->input->post('fullname'));
        $id = $this->input->post('id');

        if ($this->m_user->is_edited($data, $id)) {
            echo json_encode(array('success' => true));
        }
    }

    function get_user() {
        $id = $this->input->post('id');

        $results = $this->m_user->get_user($id);
        foreach ($results as $r) {
            $row['data'] = array(
                'id' => $r->id,
                'username' => $r->username,
                'fullname' => $r->fullname,
                'email' => $r->email
            );
        }
        echo json_encode($row);
    }

    function delete() {
        $id = $this->input->post('id');

        $result = $this->m_user->delete_user($id);
    }

}

?>